package com.github.deivily.citiesdistanceapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitiesDistanceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
